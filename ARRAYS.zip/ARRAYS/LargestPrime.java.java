import java.util.*;
class LargestPrime{
    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int a[]=new int[n];
        int x=-1;
        for(int i=0;i<n;i++)
        {
            a[i]=sc.nextInt();
            int k=0;
            for(int j=2;j<a[i]/2;j++)
            {   
                if(a[i]%j==0)
                {
                    k=1;
                    break;
                }
            }
            if(k==0)
            {
                if(x<a[i])
                {
                    x=a[i];
                }
            }
        }
        if(x==-1)
        {
            System.out.println("There is no prime numbers");
        }
        else
        {
            System.out.println("The Largest Prime number in given array: "+x);
        }
    }
}